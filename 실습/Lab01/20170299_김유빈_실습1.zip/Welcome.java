// This application program prints Welcome to Java!
public class Welcome {

	public static void main(String[] args) {
		System.out.println("Welcome to Java!");

	}

}
